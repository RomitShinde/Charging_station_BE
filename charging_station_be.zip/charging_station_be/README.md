# Charging Station — Backend

Concise instructions to set up and run the NestJS backend locally (Windows PowerShell examples).

## Requirements

- Node.js 18+ (or supported LTS)
- yarn (or npm)
- (Optional) PostgreSQL if you plan to run with TypeORM and the `pg` driver

## Quick start

1. Clone the repo and enter the folder:

```powershell
git clone <repo-url> .
cd d:\ChargingStation\charging_station_be
```

2. Install dependencies (using yarn):

```powershell
yarn install
```

Alternatively you can use npm:

```powershell
npm install
```

3. Configure environment (optional / app-specific):

- Create a `.env` file in the project root if you need to supply DB or port settings.
- Common variables the app may use:

```
PORT=3000
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=yourpassword
DB_NAME=charging_db
```

Note: This project uses TypeORM (`typeorm`, `pg`). If you don't configure DB env variables and your code expects a DB connection, startup may fail.

## Run (development)

Start the backend in watch mode (recommended during development):

```powershell
yarn start:dev
```

Or with npm:

```powershell
npm run start:dev
```

This will run the NestJS app and automatically reload on changes. By default the app listens on `process.env.PORT` or `3000`.

## Run (production)

Build and run the compiled app:

```powershell
yarn build
yarn start:prod
```

Or with npm:

```powershell
npm run build
npm run start:prod
```

## Tests & lint

- Run unit tests:

```powershell
yarn test
```

Or with npm:

```powershell
npm run test
```

- Run end-to-end tests:

```powershell
yarn test:e2e
```

Or with npm:

```powershell
npm run test:e2e
```

- Lint and format:

```powershell
yarn lint
yarn format
```

Or with npm:

```powershell
npm run lint
npm run format
```

## CORS (Vite / frontend on port 5173)

The project already includes a CORS configuration allowing `http://localhost:5173` and `http://localhost:5174` in `src/main.ts`:

- If you see CORS errors from a Vite dev server (default port 5173), either:
  - Keep the allowed origins in `src/main.ts` (already set to include `http://localhost:5173`), or
  - Update `src/main.ts` to add your frontend origin, for example:

```ts
// src/main.ts
app.enableCors({ origin: 'http://localhost:5173', credentials: true });
```

- Alternatively you can configure a proxy in your Vite app to forward `/api` calls to `http://localhost:3000` and avoid CORS during dev.

If your frontend sends cookies/auth, make sure to use `credentials: 'include'` on the client and `credentials: true` in the server CORS config.

## Troubleshooting

- CORS error: confirm the browser origin exactly matches an allowed origin in `src/main.ts` or use a Vite proxy.
- DB connection errors: ensure PostgreSQL is running and env vars match your DB credentials.
- Port conflict: change `PORT` in `.env` or stop the process using the port.

## Where to look next

- Entry point: `src/main.ts`
- Modules: `src/auth`, `src/station`, etc.
- Scripts & deps: `package.json`

If you'd like, I can add a sample `.env.example` or a debug script to make local setup even easier.

<p align="center">
  <a href="http://nestjs.com/" target="blank"><img src="https://nestjs.com/img/logo-small.svg" width="120" alt="Nest Logo" /></a>
</p>

[circleci-image]: https://img.shields.io/circleci/build/github/nestjs/nest/master?token=abc123def456
[circleci-url]: https://circleci.com/gh/nestjs/nest

  <p align="center">A progressive <a href="http://nodejs.org" target="_blank">Node.js</a> framework for building efficient and scalable server-side applications.</p>
    <p align="center">
<a href="https://www.npmjs.com/~nestjscore" target="_blank"><img src="https://img.shields.io/npm/v/@nestjs/core.svg" alt="NPM Version" /></a>
<a href="https://www.npmjs.com/~nestjscore" target="_blank"><img src="https://img.shields.io/npm/l/@nestjs/core.svg" alt="Package License" /></a>
<a href="https://www.npmjs.com/~nestjscore" target="_blank"><img src="https://img.shields.io/npm/dm/@nestjs/common.svg" alt="NPM Downloads" /></a>
<a href="https://circleci.com/gh/nestjs/nest" target="_blank"><img src="https://img.shields.io/circleci/build/github/nestjs/nest/master" alt="CircleCI" /></a>
<a href="https://discord.gg/G7Qnnhy" target="_blank"><img src="https://img.shields.io/badge/discord-online-brightgreen.svg" alt="Discord"/></a>
<a href="https://opencollective.com/nest#backer" target="_blank"><img src="https://opencollective.com/nest/backers/badge.svg" alt="Backers on Open Collective" /></a>
<a href="https://opencollective.com/nest#sponsor" target="_blank"><img src="https://opencollective.com/nest/sponsors/badge.svg" alt="Sponsors on Open Collective" /></a>
  <a href="https://paypal.me/kamilmysliwiec" target="_blank"><img src="https://img.shields.io/badge/Donate-PayPal-ff3f59.svg" alt="Donate us"/></a>
    <a href="https://opencollective.com/nest#sponsor"  target="_blank"><img src="https://img.shields.io/badge/Support%20us-Open%20Collective-41B883.svg" alt="Support us"></a>
  <a href="https://twitter.com/nestframework" target="_blank"><img src="https://img.shields.io/twitter/follow/nestframework.svg?style=social&label=Follow" alt="Follow us on Twitter"></a>
</p>
  <!--[![Backers on Open Collective](https://opencollective.com/nest/backers/badge.svg)](https://opencollective.com/nest#backer)
  [![Sponsors on Open Collective](https://opencollective.com/nest/sponsors/badge.svg)](https://opencollective.com/nest#sponsor)-->

## Description

[Nest](https://github.com/nestjs/nest) framework TypeScript starter repository.

## Project setup

```bash
$ yarn install
```

## Compile and run the project

```bash
# development
$ yarn run start

# watch mode
$ yarn run start:dev

# production mode
$ yarn run start:prod
```

## Run tests

```bash
# unit tests
$ yarn run test

# e2e tests
$ yarn run test:e2e

# test coverage
$ yarn run test:cov
```

## Deployment

When you're ready to deploy your NestJS application to production, there are some key steps you can take to ensure it runs as efficiently as possible. Check out the [deployment documentation](https://docs.nestjs.com/deployment) for more information.

If you are looking for a cloud-based platform to deploy your NestJS application, check out [Mau](https://mau.nestjs.com), our official platform for deploying NestJS applications on AWS. Mau makes deployment straightforward and fast, requiring just a few simple steps:

```bash
$ yarn install -g @nestjs/mau
$ mau deploy
```

With Mau, you can deploy your application in just a few clicks, allowing you to focus on building features rather than managing infrastructure.

## Resources

Check out a few resources that may come in handy when working with NestJS:

- Visit the [NestJS Documentation](https://docs.nestjs.com) to learn more about the framework.
- For questions and support, please visit our [Discord channel](https://discord.gg/G7Qnnhy).
- To dive deeper and get more hands-on experience, check out our official video [courses](https://courses.nestjs.com/).
- Deploy your application to AWS with the help of [NestJS Mau](https://mau.nestjs.com) in just a few clicks.
- Visualize your application graph and interact with the NestJS application in real-time using [NestJS Devtools](https://devtools.nestjs.com).
- Need help with your project (part-time to full-time)? Check out our official [enterprise support](https://enterprise.nestjs.com).
- To stay in the loop and get updates, follow us on [X](https://x.com/nestframework) and [LinkedIn](https://linkedin.com/company/nestjs).
- Looking for a job, or have a job to offer? Check out our official [Jobs board](https://jobs.nestjs.com).

## Support

Nest is an MIT-licensed open source project. It can grow thanks to the sponsors and support by the amazing backers. If you'd like to join them, please [read more here](https://docs.nestjs.com/support).

## Stay in touch

- Author - [Kamil Myśliwiec](https://twitter.com/kammysliwiec)
- Website - [https://nestjs.com](https://nestjs.com/)
- Twitter - [@nestframework](https://twitter.com/nestframework)

## License

Nest is [MIT licensed](https://github.com/nestjs/nest/blob/master/LICENSE).
