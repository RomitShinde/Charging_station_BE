import { Injectable, UnauthorizedException } from '@nestjs/common';
import { LoginDto } from './dto/login.dto';

@Injectable()
export class AuthService {
  // In a real application, these credentials should be stored securely
  private readonly defaultCredentials = {
    username: 'admin',
    password: 'root@123',
  };

  async validateUser(loginDto: LoginDto): Promise<any> {
    const { username, password } = loginDto;

    if (
      username === this.defaultCredentials.username &&
      password === this.defaultCredentials.password
    ) {
      return {
        id: 1,
        username: username,
        role: 'admin',
      };
    }

    throw new UnauthorizedException('Invalid credentials');
  }

  async login(user: LoginDto) {
    const validatedUser = await this.validateUser(user);
    
    return {
      status: 'success',
      message: 'Login successful',
      user: {
        username: validatedUser.username,
        role: validatedUser.role,
      },
    };
  }
}