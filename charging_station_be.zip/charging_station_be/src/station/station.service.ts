import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateStationDto } from './dto/create-station.dto';

export interface Station extends CreateStationDto {
  id: number;
}

@Injectable()
export class StationService {
  private stations: Station[] = [];
  private idCounter = 1;

  create(createStationDto: CreateStationDto): Station {
    const station: Station = {
      id: this.idCounter++,
      ...createStationDto,
    };
    this.stations.push(station);
    return station;
  }

  findAll(): Station[] {
    return this.stations;
  }

  findOne(id: number): Station {
    const station = this.stations.find(s => s.id === id);
    if (!station) throw new NotFoundException('Station not found');
    return station;
  }

  update(id: number, updateDto: Partial<CreateStationDto>): Station {
    const station = this.findOne(id);
    Object.assign(station, updateDto);
    return station;
  }
}
