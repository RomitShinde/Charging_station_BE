import { IsString, IsNotEmpty, IsUrl } from 'class-validator';

export class CreateStationDto {
  @IsString()
  @IsNotEmpty()
  stationName: string;

  @IsString()
  @IsNotEmpty()
  locationAddress: string;

  @IsString()
  @IsNotEmpty()
  pinCode: string;

  @IsString()
  @IsNotEmpty()
  connectorType: string;

  @IsString()
  @IsNotEmpty()
  status: string;

  @IsUrl()
  image: string;

  @IsUrl()
  locationLink: string;
}
