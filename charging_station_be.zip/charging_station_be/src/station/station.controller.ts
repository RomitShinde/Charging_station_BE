import { Body, Controller, Get, Param, Patch, Post } from '@nestjs/common';
import { CreateStationDto } from './dto/create-station.dto';
import { StationService } from './station.service';

@Controller('station')
export class StationController {
  constructor(private readonly stationService: StationService) {}

  @Post()
  create(@Body() createStationDto: CreateStationDto) {
    const station = this.stationService.create(createStationDto);
    return {
      message: 'Station created successfully',
      station,
    };
  }

  @Get()
  getAll() {
    return this.stationService.findAll();
  }

  @Get(':id')
  getOne(@Param('id') id: string) {
    return this.stationService.findOne(Number(id));
  }

  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() updateDto: Partial<CreateStationDto>,
  ) {
    const station = this.stationService.update(Number(id), updateDto);
    return {
      message: 'Station updated successfully',
      station,
    };
  }
}
